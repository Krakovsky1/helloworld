// Unity: Assets > Tropical Resort > Setup (materials + prefabs)
// Skopiruj priecinok TropicalResort_Models do Assets/. Skript nastavi materialy (URP/Standard) a vytvori prefaby.
using UnityEngine;
using UnityEditor;
using System.IO;
using System.Collections.Generic;

public static class TropicalResortSetup
{
    [MenuItem("Assets/Tropical Resort/Setup")]
    public static void Setup()
    {
        string root = "Assets/TropicalResort_Models";
        string matDir = root + "/Materials"; Directory.CreateDirectory(matDir);
        Shader sh = Shader.Find("Universal Render Pipeline/Lit"); if (sh == null) sh = Shader.Find("Standard");
        var mats = new Dictionary<string, Material>();
        foreach (var line in File.ReadAllLines(root + "/TropicalResort.mtl"))
        {
            // parse newmtl / Kd / d
            if (line.StartsWith("newmtl ")) { cur = line.Substring(7).Trim(); curKd = Color.white; }
            else if (line.StartsWith("Kd ")) { var p = line.Split(' '); curKd = new Color(float.Parse(p[1], ci), float.Parse(p[2], ci), float.Parse(p[3], ci)); }
            else if (line.StartsWith("d "))
            {
                curKd.a = float.Parse(line.Split(' ')[1], ci);
                var m = new Material(sh) { name = cur };
                m.SetColor("_BaseColor", curKd); m.SetColor("_Color", curKd);
                if (curKd.a < 0.99f) { m.SetFloat("_Surface", 1); m.renderQueue = 3000; }
                AssetDatabase.CreateAsset(m, matDir + "/" + cur + ".mat"); mats[cur] = m;
            }
        }
        string prefDir = root + "/Prefabs"; Directory.CreateDirectory(prefDir);
        foreach (var guid in AssetDatabase.FindAssets("t:Model", new[] { root }))
        {
            string path = AssetDatabase.GUIDToAssetPath(guid);
            var imp = AssetImporter.GetAtPath(path) as ModelImporter; if (imp == null) continue;
            imp.materialImportMode = ModelImporterMaterialImportMode.None; imp.SaveAndReimport();
            var go = (GameObject)Object.Instantiate(AssetDatabase.LoadAssetAtPath<GameObject>(path));
            foreach (var r in go.GetComponentsInChildren<MeshRenderer>())
            {
                // submesh materials by group name suffix: Name_material
                string n = r.gameObject.name; int i = n.LastIndexOf('_');
                string key = n.Substring(i + 1);
                // material names with underscore (e.g. palm_leaf) - try progressively
                Material mm = null; var parts = n.Split('_');
                for (int k = 1; k < parts.Length && mm == null; k++) mats.TryGetValue(string.Join("_", parts, k, parts.Length - k), out mm);
                if (mm != null) r.sharedMaterial = mm;
            }
            PrefabUtility.SaveAsPrefabAsset(go, prefDir + "/" + Path.GetFileNameWithoutExtension(path) + ".prefab");
            Object.DestroyImmediate(go);
        }
        AssetDatabase.SaveAssets(); Debug.Log("Tropical Resort: hotovo.");
    }
    static string cur; static Color curKd; static readonly System.Globalization.CultureInfo ci = System.Globalization.CultureInfo.InvariantCulture;
}
