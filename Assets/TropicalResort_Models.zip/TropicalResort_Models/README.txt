TROPICAL RESORT – low-poly 3D modely (74 objektov, OBJ + MTL)
1 jednotka = 1 meter, os Y hore, pivot v strede pôdorysu na y=0. Budovy majú dlaždicu 3–4 m (letisko 8 m).
Import: skopíruj priečinok do Assets/ a spusti Assets > Tropical Resort > Setup (nastaví materiály a vytvorí prefaby).
Kategórie: Hotels, Gastronomy, Wellness, Infrastructure, Services, Attractions, Transport, Guests, Staff, UI.
Úrovne 1–4 = samostatné modely (_L1.._L4). UpgradeArrow = šípka vylepšenia.
Poznámka: ide o procedurálne low-poly modely (ploché farby, bez textúr), nie sculpt podľa obrázka.
